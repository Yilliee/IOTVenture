# IOTVenture
Yet another weird project with no scope :)
